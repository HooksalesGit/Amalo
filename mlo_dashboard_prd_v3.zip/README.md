# Mortgage Income & DTI Dashboard

Run:

```bash
pip install -r requirements.txt
streamlit run app.py
```
